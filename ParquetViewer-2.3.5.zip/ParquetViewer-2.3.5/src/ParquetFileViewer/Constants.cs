﻿namespace ParquetFileViewer
{
    public static class Constants
    {
        public const string FILL_WEIGHT_EXCEPTION_MESSAGE = "FillWeight";
    }

    public enum ParquetEngine
    {
        Default,
        Default_Multithreaded
    }
}
